#from projectname.wsgi import application
from myproject.wsgi import application